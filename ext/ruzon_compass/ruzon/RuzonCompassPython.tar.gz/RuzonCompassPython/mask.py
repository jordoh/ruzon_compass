import math, Numeric
from types import *

MINWEIGHT = .001

class parameters:
    def __init__(self, left, right, bot, top, slope1, slope2, radius):
        self.left = left
        self.right = right
        self.bot = bot
        self.top = top
        self.slope1 = slope1
        self.slope2 = slope2
        self.radius = radius

    def __repr__(self):
        return repr( (self.left, self.right, self.bot, self.top,
                 self.slope1, self.slope2, self.radius) )

def printpretty_rev(nwedges, radius, out):
    rev = range(radius)
    rev.reverse()
    for i in range(nwedges):
        print 'wedge', i
        for r in rev:
            for c in range(radius):
                print '%5.3f ' % out[i][r][c],
            print
        print
    print

def printpretty(nwedges, radius, out):
    for i in range(nwedges):
        print 'wedge', i
        for r in range(radius):
            for c in range(radius):
                print '%5.2f' % out[i][r][c],
            print
        print
    print

def printpretty2(text, radius, out):
    print text
    for r in range(radius):
        for c in range(radius):
            print '%5.2f' % out[r][c],
        print
    print

def intersections(params):
    # L1, l2 mean line through origin; C circle.
    # i means intersect.
    def L1ICi(params):
        return params.radius / math.sqrt(1.0 + params.slope1*params.slope1)
    def L2iC(params):
        return params.radius / math.sqrt(1.0 + params.slope2*params.slope2)
    def L1iBot(params):
        if params.slope1 == 0.0:
            return -1.0
        return float(params.bot) / params.slope1
    def L1iTop(params):
        if params.slope1 == 0.0:
            return -1.0
        return float(params.top) / params.slope1
    def L2iBot(params):
        return float(params.bot) / params.slope2
    def L2iTop(params):
        return float(params.top) / params.slope2
    def CiBot(params):
        return math.sqrt(params.radius*params.radius - params.bot*params.bot)
    def CiTop(params):
        return math.sqrt(params.radius*params.radius - params.top*params.top)

    if params.slope2 is None:  # L2 vertical.
        alltheexes = [L1ICi(params), L1iBot(params), L1iTop(params),
             CiBot(params), CiTop(params)]
    else:
        alltheexes = [L1ICi(params), L2iC(params), L1iBot(params), L1iTop(params),
             L2iBot(params), L2iTop(params), CiBot(params), CiTop(params)]
    allgoodexes = [params.left, params.right]
    for x in alltheexes:
        if x > params.left and x < params.right:
            allgoodexes.append(x)
    allgoodexes.sort()
    return allgoodexes    

# Length of interval below pt1 and pt2 but above bot and below top.
def belowline(bot, top, pt1, pt2):
    b = bot
    t = min(top, pt1, pt2)
    if t - b > 0:
        return t - b
    return 0

# Length of interval above pt1 and below pt2 but above bot and below top.
def aboveline(bot, top, pt1, pt2):
    b = max(bot, pt1)
    t = min(top, pt2)
    if t - b > 0:
        return t - b
    return 0

def line(m, x):
    return m*x

def circle(r, x):
    return math.sqrt(r*r - x*x)

# m1 < m2 required.
def lines2(x, params):
    lower = belowline(params.bot, params.top,
           line(params.slope1, x), circle(params.radius, x))
    upper = belowline(params.bot, params.top,
           line(params.slope2, x), circle(params.radius, x))
    return upper - lower

def which(lo, hi, params):
    mid = (lo + hi)/2.0
    d = {}
    d[None] = None
    d['Top'] = params.top
    d['Bot'] = params.bot
    d['C'] = circle(params.radius, mid)        
    d['L1'] = line(params.slope1, mid)
    if params.slope2 is not None:
        d['L2'] = line(params.slope2, mid)
    # Remember that d['L2'] > d['L1'].
    if params.slope2 is not None and d['C'] > d['L2']:
        upper = 'L2'
        lower = 'L1'
    elif d['C'] > d['L1']:
        upper = 'C'
        lower = 'L1'
    else:
        upper = lower = None
    if d[upper] is not None and d[upper] > params.top:
        upper = 'Top'
    if d[upper] is not None and d[upper] <= params.bot:
        upper = lower = None
    if d[lower] is not None and d[lower] < params.bot:
        lower = 'Bot'
    if d[lower] is not None and d[lower] >= params.top:
        upper = lower = None
    return lower, upper

def Cintegrate(lo, hi, params):
    def indefinite(x, params):
        r = float(params.radius)
        xx = float(x)
        return (xx*math.sqrt(r*r - xx*xx) + r*r*math.asin(xx/r))/2.0

    return indefinite(hi, params) - indefinite(lo, params)

def L1integrate(lo, hi, params):
    return params.slope1*hi*hi/2.0 - params.slope1*lo*lo/2.0

def L2integrate(lo, hi, params):
    return params.slope2*hi*hi/2.0 - params.slope2*lo*lo/2.0

def Tintegrate(lo, hi, params):
    return params.top * (hi - lo)

def Bintegrate(lo, hi, params):
    return params.bot * (hi - lo)

def integrate(left, right, lower, upper, params):
    if lower == None or upper == None:
        return 0.0
    pair = [lower, upper]
    integrals = [0, 0]
    for i in (0,1):
        if pair[i] == 'None':
            integrals[i] = 0.0
        if pair[i] == 'Top':
            integrals[i] = Tintegrate(left, right, params)
        if pair[i] == 'Bot':
            integrals[i] = Bintegrate(left, right, params)
        if pair[i] == 'L1':
            integrals[i] = L1integrate(left, right, params)
        if pair[i] == 'L2':
            integrals[i] = L2integrate(left, right, params)
        if pair[i] == 'C':
            integrals[i] = Cintegrate(left, right, params)
    return integrals[1] - integrals[0]

def quadrant(nwedges, radius):
    slopes = []
    for i in range(nwedges):
        slopes.append(math.tan(i * math.pi / (2*nwedges)))
    slopes.append(None)

    arr = Numeric.zeros((nwedges, radius, radius), 'd')
    for i in range(nwedges):
        for r in range(radius):
             for c in range(radius):
                  params = parameters(c, c+1, r, r+1,
                                slopes[i], slopes[i+1], radius)
                  allgoodexes = intersections(params)
                  sum = 0.0
                  for k in range(len(allgoodexes) - 1):
                      lower, upper = \
                        which(allgoodexes[k], allgoodexes[k+1], params)
                      area = integrate(allgoodexes[k], allgoodexes[k+1],
                           lower, upper, params)
                      sum += area
                  if sum < 0.0 or sum > 1.0:
                      print i, r, c, sum
                      raise ValueError, 'sum must be between 0 and 1.'
                  arr[i,r,c] = sum
    return arr

def wedges(nwedges, radius):
    bigarr = Numeric.zeros((4*nwedges, 2*radius, 2*radius), 'd')
    arr = quadrant(nwedges, radius)
    for i in range(nwedges):
        for r in range(radius):
            for c in range(radius):
                bigarr[0*nwedges+i, radius-1-r, radius+c] = arr[i,r,c]
                bigarr[1*nwedges+i, radius-1-c, radius-1-r] = arr[i,r,c]
                bigarr[2*nwedges+i, radius+r, radius-1-c] = arr[i,r,c]
                bigarr[3*nwedges+i, radius+c, radius+r] = arr[i,r,c]
    return bigarr

def weight(radius, sigma, nwedges, bigarr):
    def rayleigh(r, sigma):
        r = float(r)
        return r * math.exp(-(r*r)/(2*sigma*sigma))
    def gauss(r, sigma):
        r = float(r)
        return math.exp(-(r*r)/(2*sigma*sigma))
    def linear(r, radius):
        r = float(r)
        return 1.0 - r / radius
    def distrib(r, c, radius, sigma):
        # The center of the pixel at (r, c) is (r + .5, c + .5).
        # Remember that the mask has even size and so is centered between
        # pixels.
        p = radius - r - 0.5
        q = radius - c - 0.5
        r = math.sqrt(p*p + q*q)
        return rayleigh(r, sigma)

    distarr = Numeric.zeros((2*radius, 2*radius), 'd')
    for r in range(2*radius):
        for c in range(2*radius):
            distarr[r,c] = distrib(r, c, radius, sigma)
#    printpretty2('distarr', 2*radius, distarr)
    distbig = Numeric.array(4*nwedges*[distarr], 'd')
    bigarr *= distbig
    bigarr = Numeric.where(bigarr > MINWEIGHT, bigarr, 0)
    sumarr = Numeric.add.reduce(bigarr)
    npoints = 0
    # In the original, the number of non-zero points are calculated here.
    # The answer is usually 4*radius*radius.
    for r in range(2*radius):
        for c in range(2*radius):
            if sumarr[r,c] != 0.0:
                npoints += 1
    return npoints, bigarr, sumarr

def CreateMasks(sigmas, nwedges):
    if type(sigmas) != ListType and type(sigmas) != TupleType:
        sigmas = [sigmas]
    mask_list = []
    sumarr_list = []
    npoints_list = []
    for sigma in sigmas:
        radius = int(math.ceil(3*sigma))
        bigarr = wedges(nwedges, radius)
        npoints, mask, sumarr = weight(radius, sigma, nwedges, bigarr)
        mask_list.append(mask)
        sumarr_list.append(sumarr)
        npoints_list.append(npoints)
    return npoints_list, mask_list, sumarr_list
