import Numeric

def makeluts():
    edges = ((1.0, 0.0, 0.0), (1.0, 1.0, 0.0), (0.0, 1.0, 0.0),
             (0.0, 1.0, 1.0), (0.0, 0.0, 1.0), (1.0, 0.0, 1.0),
             (1.0, 0.0, 0.0))
    luts = [[0], [0], [0]]
    for i in range(6):
        for j in range(30):
            for k in (0,1,2):
                value = int(6 * ((30-j)*edges[i][k] + j*edges[i+1][k]))
                luts[k].append(value)
    return luts

def prettyim(ori, str=None):
    luts = makeluts()
    ori = Numeric.transpose(ori, (2,0,1))
    ori = ori[0]
    rows = ori.shape[0]
    cols = ori.shape[1]
    ori = ori.astype('i') + 1
    out = Numeric.zeros((3, rows, cols), 'i')
    for i in (0,1,2):
        out[i] = Numeric.choose(ori, luts[i])
    out = Numeric.transpose(out, (1,2,0))
    if str is not None:
        out = out*str
    return out.astype('b')
