/* bs.h
 *
 * Mark A. Ruzon
 * Stanford Vision Laboratory
 * 8 September 1998
 *
 * Header file for bs.c
 * 
 */
#ifndef BS_H
#define BS_H

#define DIM 3
#define MAXCLUSTERS 40

typedef float Coord;

static void bs(Coord *points, int npoints, int maxclusters, int *nclusters, 
      Coord **clusters, int *index);

#endif
