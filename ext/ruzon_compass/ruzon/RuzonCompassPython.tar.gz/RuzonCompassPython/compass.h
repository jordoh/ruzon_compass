#ifndef COMPASS_H
#define COMPASS_H

#include "bs.h"
#include "emd.h"

#define MAXWEDGES 30
#define MAXRESPONSES 3

/* #define SUBSCRIPT2(arr, i, j, type) (*((type*) ((arr)->data + \
       (i)*(arr)->strides[0] + (j)*(arr)->strides[1] + \
          cksubscript2(arr, i, j)))) */

#define SUBSCRIPT2(arr, i, j, type) (*((type*) ((arr)->data + \
       (i)*(arr)->strides[0] + (j)*(arr)->strides[1])))

#define ADDRESS2(arr, i, j, type) ((type*) ((arr)->data + \
       (i)*(arr)->strides[0] + (j)*(arr)->strides[1]))

static int cksubscript2(PyArrayObject* arr, int i, int j)
{
    int x;
    if (arr->nd != 2) {
        printf("SUBSCRIPT2 arr->nd != 2\n");
        fflush(stdout);
        x = 1/0;
    }
    if (i < 0 || i >= arr->dimensions[0] ||
            j < 0 || j >= arr->dimensions[1]) {
        printf("SUBSCRIPT2 bad index: %d (%d) %d (%d)\n",
            i, arr->dimensions[0], j, arr->dimensions[1]);
        fflush(stdout);
        x = 1/0;
    }
    return 0;
}

/* #define SUBSCRIPT3(arr, i, j, k, type) (*((type*) ((arr)->data + \
    (i)*(arr)->strides[0] + (j)*(arr)->strides[1] + (k)*(arr)->strides[2] + \
        cksubscript3(arr, i, j, k)))) */

#define SUBSCRIPT3(arr, i, j, k, type) (*((type*) ((arr)->data + \
    (i)*(arr)->strides[0] + (j)*(arr)->strides[1] + (k)*(arr)->strides[2])))

#define ADDRESS3(arr, i, j, k, type) ((type*) ((arr)->data + \
    (i)*(arr)->strides[0] + (j)*(arr)->strides[1] + (k)*(arr)->strides[2]))

static int cksubscript3(PyArrayObject* arr, int i, int j, int k)
{
    int x;
    if (arr->nd != 3) {
        printf("SUBSCRIPT3 arr->nd != 3\n");
        fflush(stdout);
        x = 1/0;
    }
    if (i < 0 || i >= arr->dimensions[0] ||
           j < 0 || j >= arr->dimensions[1] ||
           k < 0 || k >= arr->dimensions[2]) {
        int x;
        printf("SUBSCRIPT3 bad index %d (%d) %d (%d) %d (%d)\n",
              i, arr->dimensions[0], j, arr->dimensions[1], k, arr->dimensions[2]);
        fflush(stdout);
        x = 1/0;
    }
    return 0;
}

#define LabSUB(i, j, k) SUBSCRIPT3(Lab, i, j, k, float)
#define histSUB(i, j) SUBSCRIPT2(hist, i, j, double)
#define masksumSUB(i, j) SUBSCRIPT2(masksum, i, j, double)
#define pointsSUB(i, j) SUBSCRIPT2(points, i, j, float)
#define clusterSUB(i, j) SUBSCRIPT2(cluster, i, j, float)
#define maskSUB(i, j, k) SUBSCRIPT3(mask, i, j, k, double)
#define strSUB(i, j, k) SUBSCRIPT3(str, i, j, k, double)
#define abSUB(i, j, k) SUBSCRIPT3(ab, i, j, k, double)
#define oriSUB(i, j, k) SUBSCRIPT3(ori, i, j, k, double)
#define uncSUB(i, j, k) SUBSCRIPT3(unc, i, j, k, double)
#define strengthSUB(i, j) SUBSCRIPT2(strength, i, j, PyObject*)
#define abnormalitySUB(i, j) SUBSCRIPT2(abnormality, i, j, PyObject*)
#define orientationSUB(i, j) SUBSCRIPT2(orientation, i, j, PyObject*)
#define uncertaintySUB(i, j) SUBSCRIPT2(uncertainty, i, j, PyObject*)
#define dataSUB(i, j) SUBSCRIPT2(data, i, j, float)

#define PyPrint(text, obj)  printf(text); printf(": "); \
    PyObject_Print((PyObject*) (obj), stdout, 0); printf("\n"); fflush(stdout)

static int ckindex(char* text, int index, int size)
{
    if (index < 0 || index >= size) {
        printf(text);
        printf("\n");
        PyErr_SetString(PyExc_IndexError, "C array index out of range.");
        fflush(stdout);
        return 0;
    }
    return 1;
}

static void FreeOutputArrays(PyObject** pyout, int num_outputs);
static PyObject** CreateOutputArrays(int numsigmas, int numangles,
     int rows, int cols,
     int num_outputs, double* spacing, int maxradius, int nwedges);

static void AddWeight(PyArrayObject* Lab,
          double weight, int row, int col,
          PyArrayObject* data, PyArrayObject* hist, int wedge,
          float com[][DIM], float sum[], int nclusters);
static float dist(feature_t *F1, feature_t *F2);
static float RandomizedSelect(float *A, int p, int r, int i);
static int ClusterPoints(PyArrayObject* Lab, PyArrayObject* masksum, 
              int radius, int totalpoints, int r, int c, 
              double totalweight, float maxweight, int maxclusters, 
              PyArrayObject* cluster);
static void CreateWedgeHistograms(PyArrayObject* Lab, PyArrayObject* mask,
                      int r, int c, int radius, int nwedges,
                      PyArrayObject* cluster, int nclusters, PyArrayObject* hist);
static void ComputeCostMatrix(PyArrayObject* cluster, int nclusters);
static void ComputeOutputParameters(float *work, int nwedges, int nori,
                 int row, int col,
                 PyArrayObject* str, PyArrayObject* ab,
                 PyArrayObject* unc, PyArrayObject* ori);
static void ExtractMaskData(PyObject* maskdata, int n,
     PyArrayObject** mask, PyArrayObject** sumarr, int* npoints);
static void _Compass(PyObject* arr, PyObject* maskdata,
             double *sigmas, int numsigmas, int maxradius, double *spacing, 
             double *angles, int numangles, int nwedges, 
             double *maxclusters, PyObject* pyout[4]);
PyObject* Compass(PyObject* arrin, PyObject* maskdata,
         int num_outputs, int nwedges,
         int numsigmas, double *sigmas,
         int numspacing, double *spacing, 
         int numangles, double *angles,
         int nummaxclusters, double *maxclusters);

#endif
