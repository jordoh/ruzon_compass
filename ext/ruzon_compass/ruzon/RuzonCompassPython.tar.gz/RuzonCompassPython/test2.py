#! /usr/bin/env python

# IM and imfuncs are part of a Python / SWIG wrapper I did for PIL, Numeric,
# and the Intel OpenCV.
import Numeric, compass, IM, imfuncs, mask, os, orilut, time

infile = 'images/water.ppm'
arrin = IM.Open(infile)
arrin = Numeric.transpose(arrin, (2,0,1))
numout = 4
nwedges = 6
sigmas = [.7]
spacing = [1]
angles = [180]
maxclusters = [10]
maskdata = mask.CreateMasks(sigmas, nwedges)
t = time.clock()
out = compass.Compass(arrin, maskdata,
     4, nwedges, sigmas, spacing, angles, maxclusters)
print 'Compass completed in', time.clock() - t, 'secs.'
names = ('strength', 'orientation', 'abnormality', 'uncertainty')
head, tail = os.path.split(infile)
root, ext = os.path.splitext(tail)
for i in range(numout):
    print names[i], imfuncs.MinMax(out[i][0,0])
    arr = out[i][0,0]
    if i == 0:
        str = arr
        arr = (255*arr).astype('b')
    elif i == 1:
        ori = orilut.prettyim(arr, str)
        newtail = '%s_strXori.ppm' % root
        outfile = os.path.join('out', newtail)
        IM.Save(ori, outfile)
        arr = (arr+1.0).astype('b')
    else:
        arr = imfuncs.Stretch(arr, 0, 255).astype('b')
    newtail = '%s_%s.ppm' % (root, names[i])
    outfile = os.path.join('out', newtail)
    IM.Save(arr, outfile)
