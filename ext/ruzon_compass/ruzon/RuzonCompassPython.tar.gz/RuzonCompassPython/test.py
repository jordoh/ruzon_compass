#! /usr/bin/env python

import Numeric, compass, IM, imfuncs, mask

arrin = IM.Open('images/face.ppm')
arrin = Numeric.transpose(arrin, (2,0,1))
nwedges = 6
sigmas = [.7]
spacing = [1]
angles = [180]
maxclusters = [10]
maskdata = mask.CreateMasks(sigmas, nwedges)
out = compass.Compass(arrin, maskdata,
     1, nwedges, sigmas, spacing, angles, maxclusters)
print 'L13 Compass completed'
for i in (0,):
    print out[i][0,0].shape, out[i][0,0].typecode()
    print imfuncs.MinMax(out[i][0,0])
arr = out[0][0,0]
#arr.shape = (43, 36)
#arr = Numeric.transpose(arr)
#print arr.shape
#arr = Numeric.resize(arr, (36, 36))
#print arr[8:16, 8:16]
#arr = (100*arr).astype('b')
arr = imfuncs.Stretch(arr, 0, 255).astype('b')
print arr.shape, arr.typecode()
#arr = Numeric.array(1024*[arr])
#arr.shape = (32, 32, 3, 29)
#arr = Numeric.transpose(arr, (2, 0, 3, 1))
#arr = Numeric.array(arr)
#arr.shape = (3*32, 29*32)
IM.Save(arr, "mess.ppm")
